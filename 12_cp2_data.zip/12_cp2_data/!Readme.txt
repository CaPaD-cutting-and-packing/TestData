* Data set for the paper

M. Mesyagutov, G. Scheithauer, and G. Belov
LP bounds in various constraint programming approaches for orthogonal packing //
Computers and Operations Research, 39(10): 2425-2438, 2012.
http://dx.doi.org/10.1016/j.cor.2011.12.010
http://www.sciencedirect.com/science/article/pii/S0305054811003650

* Description

$name$.txt         - problem set
$name$_Bounds.txt  - bounds
$name$_list.txt    - list of names in set $name$
$name$.xls         - results for set $name$

* Difference!!!

Results for Disjunctive and Disjunctive+LP-Pair in Gleb_opp_gen are obtained by IBM CPLEX 12.4. In the paper we used IBM CPLEX 12.1. It explains the difference in results for these columns.

